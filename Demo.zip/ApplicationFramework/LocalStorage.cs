﻿using OpenQA.Selenium;
using System;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    class LocalStorage
    {
        private IJavaScriptExecutor js;
        IWebDriver driver;
        public LocalStorage(IWebDriver driver)
        {
            this.driver = driver;
            this.js = (IJavaScriptExecutor)driver;
        }

        public void setItemInLocalStorage(String item, String value)
        {
            js.ExecuteScript(String.Format("window.localStorage.setItem('" + item + "','" + value + "');"));
        }

        public void removeItemFromLocalStorage(String item)
        {
            js.ExecuteScript(String.Format("window.localStorage.removeItem('" + item + "');"));
        }

        public Boolean isItemPresentInLocalStorage(String item)
        {
            return !(js.ExecuteScript(String.Format("return window.localStorage.getItem('" + item + "');", item)) == null);
        }

        public String getItemFromLocalStorage(String key)
        {
            return (String)js.ExecuteScript(String.Format("return window.localStorage.getItem('" + key + "');", key));
        }

        public String getKeyFromLocalStorage(int key)
        {
            return (String)js.ExecuteScript(String.Format("return window.localStorage.key('" + key + "');", key));
        }

        public long getLocalStorageLength()
        {
            return (long)js.ExecuteScript("return window.localStorage.length;");
        }

        public void clearLocalStorage()
        {
            js.ExecuteScript(String.Format("window.localStorage.clear();"));
        }
    }
}

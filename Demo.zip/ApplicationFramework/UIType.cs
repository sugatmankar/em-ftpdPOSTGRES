﻿namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    public enum UIType
    {
        TEXTBOX,
        BUTTON,
        RADIOBUTTON,
        CHECKBOX,
        LINK,
        DROPDOWN,
        TEXTAREA,
        LABEL

    }
}

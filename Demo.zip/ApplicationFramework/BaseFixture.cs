﻿using AventStack.ExtentReports;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Remote;
using System;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    public class BaseFixture
    {
        private static IWebDriver driver = null;
        public static string browser = "safari";

        [OneTimeSetUp]
        public void Setup()
        {
            ExtentTestManager.CreateParentTest(GetType().Name);
            FileCreations.GetReportFolderPath();
            FileCreations.GetScreenshotFolderPath();
        }

        [OneTimeTearDown]
        protected void TearDown()
        {
            ExtentManager.Instance.Flush();
        }

        [SetUp]
        public void BeforeTest()
        {
            ExtentTestManager.CreateTest(TestContext.CurrentContext.Test.Name);

            DesiredCapabilities capabilites = new DesiredCapabilities();

            if (browser.Equals("chrome"))
            {
                var options = new ChromeOptions()
                {

                };
                driver = new RemoteWebDriver(new Uri("http://localhost:4449/wd/hub"), options.ToCapabilities());
                driver.Manage().Window.Maximize();
            }
            else if (browser.Equals("firefox"))
            {
                var options = new FirefoxOptions()
                {

                };
                driver = new RemoteWebDriver(new Uri("http://localhost:4449/wd/hub"), options.ToCapabilities());
                driver.Manage().Window.Maximize();
            }
            else if (browser.Equals("ie"))
            {
                var options = new InternetExplorerOptions()
                {
                    //IntroduceInstabilityByIgnoringProtectedModeSettings = false,
                    //IgnoreZoomLevel = true,
                    //EnableNativeEvents = false,
                    //EnablePersistentHover = true,
                    //ForceCreateProcessApi = false,
                    //RequireWindowFocus = false,

                };
                driver = new RemoteWebDriver(new Uri("http://localhost:4449/wd/hub"), options.ToCapabilities());
                driver.Manage().Window.Maximize();
            }
            else if (browser.Equals("edge"))
            {
                var options = new OpenQA.Selenium.Edge.EdgeOptions();
                {

                };
                driver = new RemoteWebDriver(new Uri("http://localhost:4449/wd/hub"), options.ToCapabilities());
                driver.Manage().Window.Maximize();
            }
            else if (browser.Equals("safari"))
            {
                capabilites.SetCapability("browserName", "Safari");//50
                capabilites.SetCapability("automationName", "XCUITest");
                capabilites.SetCapability("platformName", "iOS");
                /*capabilites.SetCapability("deviceName", "QA IPad3");
                capabilites.SetCapability("udid", "bdcb3e880d383c3427e31c1deabf4f580578833a");
                capabilites.SetCapability("wdaLocalPort", "8726");
                capabilites.SetCapability("plateformVersion", "11.2.6"); */
                capabilites.SetCapability("deviceName", "iPhoneAuto");
                capabilites.SetCapability("udid", "ae4d04c9225684e851a842aa66f4d698f4c3f503");
                capabilites.SetCapability("wdaLocalPort", "8723");
                capabilites.SetCapability("plateformVersion", "11.2.1");

                capabilites.SetCapability("xcodeOrgId", "68QT6599HY");
                capabilites.SetCapability("xcodeSigninId", "IPhone Developer");
                capabilites.SetCapability("bundleId", "com.stars.WebDriverAgentRunnerR");
                capabilites.SetCapability("clearSystemFiles", "true");
                driver = new RemoteWebDriver(new Uri("http://localhost:4449/wd/hub"), capabilites, TimeSpan.FromSeconds(600));
            }

            driver.Manage().Timeouts().ImplicitWait = (TimeSpan.FromSeconds(15));
            driver.Manage().Timeouts().AsynchronousJavaScript = TimeSpan.FromSeconds(15);
            /* ICapabilities cap = ((RemoteWebDriver)driver).Capabilities;
             String BrowserName = cap.BrowserName;
             if (!BrowserName.Equals("safari"))
                 driver.Manage().Window.Maximize();
              */
            ApplicationCommonFunction.SetDriver(driver);


        }

        [TearDown]
        public void AfterTest()
        {

            var status = TestContext.CurrentContext.Result.Outcome.Status;
            var stacktrace = string.IsNullOrEmpty(TestContext.CurrentContext.Result.StackTrace)
                    ? ""
                    : string.Format("<pre>{0}</pre>", TestContext.CurrentContext.Result.StackTrace);
            Status logstatus;

            switch (status)
            {
                case TestStatus.Failed:
                    logstatus = Status.Fail;
                    break;
                case TestStatus.Inconclusive:
                    logstatus = Status.Warning;
                    break;
                case TestStatus.Skipped:
                    logstatus = Status.Skip;
                    break;
                default:
                    logstatus = Status.Pass;
                    break;
            }

            ExtentTestManager.GetTest().Log(logstatus, "Test ended with " + logstatus + stacktrace);
            if (logstatus == Status.Fail || logstatus == Status.Error)
            {
                ExtentTestManager.GetTest().Log(logstatus, "Error screenshot below :" + ExtentTestManager.GetTest().AddScreenCaptureFromPath(ApplicationCommonFunction.Capture("Exception")));
            }

            if (driver != null)
            {
                driver.Close();
                driver.Quit();
            }
        }
    }
}

﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Configuration;
using System;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    public class ExtentManager
    {
        private static readonly Lazy<ExtentReports> _lazy = new Lazy<ExtentReports>(() => new ExtentReports());

        public static ExtentReports Instance { get { return _lazy.Value; } }

        private static String filePath = FileCreations.ReportFolderPath + "\\CurrentReport_" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-fff") + ".html";

        static ExtentManager()
        {
            var htmlReporter = new ExtentHtmlReporter(filePath);
            //var htmlReporter = new ExtentHtmlReporter(TestContext.CurrentContext.TestDirectory + "\\Extent.html");
            htmlReporter.Configuration().ChartLocation = ChartLocation.Top;
            htmlReporter.Configuration().ChartVisibilityOnOpen = true;
            htmlReporter.Configuration().DocumentTitle = "QA Automation Report";
            htmlReporter.Configuration().ReportName = "Marsh ClearSight";
            htmlReporter.Configuration().Theme = Theme.Dark;

            Instance.AttachReporter(htmlReporter);
        }

        private ExtentManager()
        {
        }
    }
}

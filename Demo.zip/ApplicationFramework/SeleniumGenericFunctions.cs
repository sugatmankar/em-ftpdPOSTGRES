﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    public abstract class SeleniumGenericFunctions
    {
        private int waitDelayTime;
        private IWebDriver driver;
        private WebDriverWait webDriverWait;

        public void Ety(){}
    }
}

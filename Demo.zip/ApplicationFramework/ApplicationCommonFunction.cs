﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    class ApplicationCommonFunction : Logger
    {

        private static IWebDriver driver;
        private int explicitTimeoutInSecond = 30;
        private int mobileExplicitTimeoutInSecond = 50;
        WebDriverWait wait = null;

        public static bool isIPHONE = false;
        public static bool isIE = false;
        public static bool isIPAD = false;
        public static bool isAndroid = false;
        public static bool DirectlyRunThroughLink = false;
        public static void SetDriver(IWebDriver iDriver)
        {
            driver = iDriver;
        }

        public ApplicationCommonFunction()
        {
            if (isIPAD || isIPHONE || isAndroid)
            {
                wait = new WebDriverWait(driver, TimeSpan.FromSeconds(mobileExplicitTimeoutInSecond));
            }
            else
            {
                wait = new WebDriverWait(driver, TimeSpan.FromSeconds(explicitTimeoutInSecond));
            }

            ICapabilities cap = ((OpenQA.Selenium.Remote.RemoteWebDriver)driver).Capabilities;
            string device = "";
            try
            {
                device = (string)cap.GetCapability("deviceName");
                if (device.ToLower().Contains("ipad"))
                {
                    isIPAD = true;
                    DirectlyRunThroughLink = true;
                }
                else if (device.ToLower().Contains("iphone"))
                {
                    isIPHONE = true;
                    DirectlyRunThroughLink = true;
                }
                else if (device.ToLower().Contains("android"))
                {
                    isAndroid = true;
                }
            }
            catch
            {

            }

            if (cap.BrowserName.Contains("internet explorer"))
            {
                isIE = true;
            }
        }

        public string GetVariableName<T>(Expression<Func<T>> expr)
        {
            var body = (MemberExpression)expr.Body;

            return body.Member.Name;
        }

        public static string Capture(string screenShotName)
        {
            ITakesScreenshot ts = (ITakesScreenshot)driver;
            Screenshot screenshot = ts.GetScreenshot();
            string finalpth = FileCreations.ScreenshotPath + "\\" + screenShotName + ".png";
            string localpath = new Uri(finalpth).LocalPath;
            screenshot.SaveAsFile(localpath, ScreenshotImageFormat.Png);
            return localpath;
        }

        public void sendKey(UIElement element, string value)
        {
            try
            {
                IWebElement webElement = wait.Until(ExpectedConditions.ElementToBeClickable(getByLocator(element)));
                webElement = this.getWebElements(element).First(a => a.Displayed);
                if (isIE)
                {
                    Ngclick(element);
                }
                else
                {
                    webElement.Click();
                }

                webElement.Clear();
                webElement.SendKeys(value);
                webElement.SendKeys(Keys.Tab);
                driver.FindElement(By.XPath("//body")).Click();
                LogPass("SendKey: Entered " + value);
            }
            catch (Exception ex)
            {
                LogError("SendKey:: Fail to enter value " + value + " Exception: " + ex.Message);
            }
        }

        public void enterPassword(UIElement element, string value)
        {
            try
            {
                IWebElement webElement = this.getWebElement(element);
                webElement.Click();
                webElement.Clear();
                webElement.SendKeys(value);
                webElement.SendKeys(Keys.Tab);
                LogPass("EnterPassword: Entered *******");
            }
            catch (Exception ex)
            {
                LogError("EnterPassword:: Fail to enter Password. Exception: " + ex.Message);
            }
        }

        public void navigateToApplication()
        {
            string url = null;
            try
            {
                if (isIPAD || isIPHONE)
                {
                    url = "https://qaauto-trunk.csstars.com/Enterprise/default.cmdx";
                }
                else
                {
                    url = "https://qa1-clearsight.cs17.force.com/community/hydra_customlogin";
                }

                driver.Navigate().GoToUrl(url);
                waitForPageLoad();
                LocalStorage localStorage = new LocalStorage(driver);
                localStorage.setItemInLocalStorage("cs-IsAutomationMode", "true");
                LogPass("NavigateToApplication:: " + url);
                LogInfo("LocalStorage:: Set Property cs-IsAutomationMode::True to enable AutomationID on UI Elements.");
            }
            catch (Exception ex)
            {
                LogError("NavigateToApplication:: Fail to navigate to URL " + url + " Exception: " + ex.Message);
            }
        }

        internal void navigateToApp(string v)
        {
            try
            {
                LocalStorage localStorage = new LocalStorage(driver);

                if (DirectlyRunThroughLink)
                {
                    localStorage.setItemInLocalStorage("cs-IsAutomationMode", "true");
                    driver.Navigate().GoToUrl("https://qaauto-trunk.csstars.com/Enterprise/StormsPackages/Storms.ClaimsAdmin/");
                    waitForPageLoad();
                }
                else
                {
                    UIElement appElement = new UIElement(UIType.BUTTON, UILocatorType.XPATH, "//*[@class='app-item-title' and @title='" + v + "']");
                    Ngclick(appElement);
                    localStorage.setItemInLocalStorage("cs-IsAutomationMode", "true");
                }

                waitForPageLoad();
                UIElement loaderElement = new UIElement(UIType.LABEL, UILocatorType.CLASS_NAME, "loading-pulse");
                bool flag = true;
                for (int i = 0; i < 3; i++)
                {
                    try
                    {
                        flag = wait.Until(ExpectedConditions.InvisibilityOfElementLocated(this.getByLocator(loaderElement)));
                    }
                    catch
                    {
                    }
                    if (flag)
                        break;
                    else
                        continue;
                }

                LogPass("NavigateToApp:: Navigated to application " + v + " Successfully.");
            }
            catch (Exception ex)
            {
                LogError("NavigateToApp::Fail to navigate to application " + v + " Exception: " + ex.Message);
            }

        }

        public bool waitForPageLoad()
        {
            return wait.Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").Equals("complete"));
        }

        public bool waitForElementVisible(UIElement uIElement)
        {
            wait.Until(ExpectedConditions.ElementIsVisible(this.getByLocator(uIElement)));
            return true;
        }

        public void click(UIElement element)
        {
            try
            {
                IWebElement webElement = this.getWebElement(element);
                wait.Until(ExpectedConditions.ElementToBeClickable(webElement));
                webElement.Click();
                LogPass("Click:: Clicked on " + element.getLocator() + " successfully.");
            }
            catch (Exception ex)
            {
                LogError("Click::Fail to click element " + element.getLocator() + " Exception: " + ex);
            }

        }

        public void Ngclick(UIElement element)
        {
            try
            {
                IWebElement webElement = this.getWebElement(element);

                if (isIPAD || isIPHONE)
                    scrollToElement(element);

                wait.Until(ExpectedConditions.ElementToBeClickable(webElement));

                if (isIPAD || isIPHONE)
                {
                    webElement.Click();
                }
                else
                {
                    ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", webElement);
                }
                System.Threading.Thread.Sleep(100);
                LogPass("JavaScriptClick:: Clicked on " + element.getLocator() + " successfully.");
            }
            catch (Exception ex)
            {
                LogFail("JavaScriptClick::Fail to click element " + element.getLocator() + " Exception: " + ex.Message);
            }
        }

        public bool isDisplayed(UIElement element)
        {
            IWebElement webElement = this.getWebElement(element);
            if (isIPAD || isIPHONE)
                scrollToElement(element);
            return wait.Until(a => a.FindElement(this.getByLocator(element)).Displayed);
        }

        public bool isEnabled(UIElement element)
        {
            IWebElement webElement = this.getWebElement(element);
            wait.Until(ExpectedConditions.ElementToBeClickable(webElement));
            if (webElement.Enabled)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private IWebElement getWebElement(UIElement element)
        {
            try
            {
                wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(this.getByLocator(element)));
                if (isIPAD || isIPHONE)
                    scrollToElement(element);
                wait.Until(a => a.FindElement(this.getByLocator(element)).Displayed);
            }
            catch
            {
            }

            return driver.FindElement(this.getByLocator(element));
        }

        private List<IWebElement> getWebElements(UIElement element)
        {
            try
            {
                wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(this.getByLocator(element)));
                if (isIPAD || isIPHONE)
                    scrollToElement(element);
                wait.Until(a => a.FindElement(this.getByLocator(element)).Displayed);
            }
            catch
            {

            }
            return driver.FindElements(this.getByLocator(element)).ToList<IWebElement>();
        }

        public bool scrollToElement(UIElement uIElement)
        {
            // will scroll to the element
            IWebElement element = driver.FindElement(this.getByLocator(uIElement));
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", element);
            System.Threading.Thread.Sleep(100);
            return true;
        }

        private By getByLocator(UIElement element)
        {
            By by = null;
            if (element.getUILocatorType() == UILocatorType.ID)
                by = By.Id(element.getLocator());
            if (element.getUILocatorType() == UILocatorType.NAME)
                by = By.Name(element.getLocator());
            else if (element.getUILocatorType() == UILocatorType.CLASS_NAME)
                by = By.ClassName(element.getLocator());
            else if (element.getUILocatorType() == UILocatorType.CSS_SELECTOR)
                by = By.CssSelector(element.getLocator());
            else if (element.getUILocatorType() == UILocatorType.LINK_TEXT)
                by = By.LinkText(element.getLocator());
            else if (element.getUILocatorType() == UILocatorType.PARTIAL_LINK_TEXT)
                by = By.PartialLinkText(element.getLocator());
            else if (element.getUILocatorType() == UILocatorType.TAGNAME)
                by = By.TagName(element.getLocator());
            else if (element.getUILocatorType() == UILocatorType.XPATH)
                by = By.XPath(element.getLocator());
            return by;
        }

        public Boolean SelectValueFromDropdown(String Identifier, String ValueToSelect)
        {
            bool ValueSelected = false;
            UIElement dropdownElement = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//div[@automation-id='" + Identifier + "']");
            click(dropdownElement);
            UIElement dropdownElementText = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//div[@automation-id='" + Identifier + "']//input");
            getWebElement(dropdownElementText).SendKeys(ValueToSelect);
           
            try
            {
                UIElement dropdownElementValueSelect = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//span[normalize-space(text())='" + ValueToSelect + "']");
                sleepInSecond(1);
                waitForElementVisible(dropdownElementValueSelect);
                // if (isDisplayed(dropdownElementValueSelect))
                //   {
                //sendKey(dropdownElementValueSelect, Keys.Enter);
                Ngclick(dropdownElementValueSelect);
                //clickOnDropDownElement(dropdownElementValueSelect);
                waitForPleaseWaitDisappear();
                ValueSelected = true;
                return true;
                //  }
            }
            catch
            {
                UIElement dropdownElementValueSelect = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//div[@class='modal-body']//span[normalize-space(text())='" + ValueToSelect + "']");
                if (isDisplayed(dropdownElementValueSelect))
                {
                    UIElement dropdownElementValueFinalSelect = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//div[@class='modal-body']//div[contains(@class,'lookup-item')]//span[normalize-space(text())='" + ValueToSelect + "']");
                    waitForElementVisible(dropdownElementValueSelect);
                    Ngclick(dropdownElementValueFinalSelect);
                    //sendKey(dropdownElementValueSelect, Keys.Enter);
                    waitForPleaseWaitDisappear();
                    ValueSelected = true;
                    return true;
                }
            }

            if (ValueSelected == true)
            {
                LogPass("SelectValueFromDropdown::Selected value " + ValueToSelect);
                return true;
            }
            else
            {
                LogFail("SelectValueFromDropdown::Fail to select value " + ValueToSelect);
                return false;
            }
        }


        public bool SwitchtoHeaderFrameNew()
        {
            try
            {
                driver.SwitchTo().DefaultContent();
                wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("iframe[id^='canvas-outer-_:']")));
                driver.SwitchTo().Frame(driver.FindElement(By.CssSelector("iframe[id^='canvas-outer-_:']")));
                LogPass("SwitchtoHeaderIFrame::Switched to Outer iFrame");
                wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("iframe[id^='canvas-inner-_:']")));
                driver.SwitchTo().Frame(driver.FindElement(By.CssSelector("iframe[id^='canvas-inner-_:']")));
                LogPass("SwitchtoHeaderIFrame::Switched to Inner iFrame");
                return true;
            }
            catch (Exception ex)
            {
                LogError("SwitchtoHeaderIFrame::Fail to Switched to Inner iFrame");
                return false;
            }


        }

        public bool SwitchToAppFrame()
        {
            wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("iframe[id^='Storms.ClaimsAdmin']")));
            driver.SwitchTo().Frame(driver.FindElement(By.CssSelector("iframe[id^='Storms.ClaimsAdmin']")));
            LogPass("SwitchtoHeaderIFrame::Switched to Application iFrame");
            return true;
        }

        public void waitForPleaseWaitDisappear()
        {
            try
            {
                //UIElement pleaseWaitProgressBar = new UIElement(UIType.LABEL, UILocatorType.XPATH, "//div[@class='progress-bar']//span[contains(text(),'Please Wait')]");
                UIElement pleaseWaitProgressBar = new UIElement(UIType.LABEL, UILocatorType.XPATH, "//div[@class='loading-pulse']");

                bool flag = true;
                for (int i = 0; i < 5; i++)
                {
                    try
                    {
                        flag = wait.Until(ExpectedConditions.InvisibilityOfElementLocated(this.getByLocator(pleaseWaitProgressBar)));
                    }
                    catch
                    {
                    }
                    if (flag)
                        break;
                    else
                        continue;
                }
            }
            catch { }
        }

        public bool navigateToTabs(string navigateText)
        {
            UIElement selectItem = new UIElement(UIType.DROPDOWN, UILocatorType.XPATH, "//button[@aria-label='Select item']");
            click(selectItem);
            UIElement itemToSelect = new UIElement(UIType.LABEL, UILocatorType.XPATH, "//button[@aria-label='Select item']//following-sibling::ul//li//span");
            List<IWebElement> optionList = getWebElements(itemToSelect);
            optionList.Find(a => a.Text.Trim().Equals(navigateText)).Click();
            UIElement uIElementSelected = new UIElement(UIType.LABEL, UILocatorType.XPATH, "//button[@aria-label='Select item']//span[@class='dd-label']");
            if (this.getWebElement(uIElementSelected).Text.Trim().Equals(navigateText))
            {
                LogPass("Successfully navigated to '" + navigateText + "' tab!!");
            }
            else
            {
                LogFail("Failed to navigate to '" + navigateText + "' tab!!");
                return false;
            }

            return true;
        }

        public bool setDateinOnDemand(UIElement uiElement, DateTime dateToSet, bool isVerify = true)
        {

            string monthtoSet = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(dateToSet.Month);
            string yeartoSet = dateToSet.Year.ToString();
            string datetoSet = dateToSet.Day.ToString("00");
            DateTime currentDateTime = DateTime.Now;
            string currentMonth = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(currentDateTime.Month);
            string currentYear1 = currentDateTime.Year.ToString();
            string currentDate = currentDateTime.Day.ToString("00");
            getWebElement(uiElement).FindElement(By.XPath("..//button[@class='btn btn-default calendar-button']")).Click();
            //Ngclick(new UIElement(UIType.LABEL,UILocatorType.XPATH, "..//button[@class='btn btn-default calendar-button']"));

            IWebElement elementTableDatePicker = getWebElements(new UIElement(UIType.LABEL, UILocatorType.TAGNAME, "table")).First(a => a.Displayed);

            List<IWebElement> thList = elementTableDatePicker.FindElement(By.TagName("thead")).FindElements(By.TagName("th")).ToList<IWebElement>();
            string text = thList[1].FindElement(By.TagName("button")).Text;
            string currentYear = text.Split(new char[] { ' ' })[1];
            if (!text.ToLower().Equals((monthtoSet + " " + yeartoSet).ToLower()))
            {
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", thList[1].FindElement(By.TagName("button")));

                if (!text.ToLower().Equals(yeartoSet.ToLower()))
                {
                    int noofTimesClick = Convert.ToInt32(currentYear) - Convert.ToInt32(yeartoSet);
                    if (noofTimesClick > 0)
                    {
                        for (int i = 0; i < noofTimesClick; i++)
                        {
                            List<IWebElement> thList1 = driver.FindElement(By.TagName("table")).FindElement(By.TagName("thead")).FindElements(By.TagName("th")).ToList<IWebElement>();
                            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", thList1[0].FindElement(By.TagName("button")));
                        }

                    }
                    else if (noofTimesClick < 0)
                    {
                        for (int i = 0; i < Math.Abs(noofTimesClick); i++)
                        {
                            List<IWebElement> thList1 = driver.FindElement(By.TagName("table")).FindElement(By.TagName("thead")).FindElements(By.TagName("th")).ToList<IWebElement>();
                            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", thList1[2].FindElement(By.TagName("button")));
                        }

                    }

                }
                List<IWebElement> tdinTbodyList = driver.FindElement(By.TagName("table")).FindElement(By.TagName("tbody")).FindElements(By.TagName("td")).ToList<IWebElement>();
                foreach (IWebElement td in tdinTbodyList)
                {
                    if (td.Text.ToLower().Equals(monthtoSet.ToLower()))
                    {
                        ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", td.FindElement(By.TagName("button")));
                        break;
                    }
                }
            }

            try
            {
                IWebElement dateButton = driver.FindElement(By.XPath("//table//tbody//td//span[text()='" + datetoSet + "' and not(@class='text-muted')]/parent::button"));
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", dateButton);
                getWebElement(uiElement).SendKeys(Keys.Tab);
                sleepInSecond(1);
                driver.FindElement(By.XPath("//body")).Click();
            }
            catch
            {
                IWebElement elementTableDatePicker3 = driver.FindElement(By.TagName("table"));
                List<IWebElement> tdinTbodyforDayList = elementTableDatePicker3.FindElement(By.TagName("tbody")).FindElements(By.TagName("td")).ToList<IWebElement>();
                int index = 0;
                IWebElement buttonElement;
                foreach (IWebElement tdofDay in tdinTbodyforDayList)
                {
                    try
                    {
                        index++;
                        buttonElement = tdofDay.FindElement(By.TagName("button"));
                        if (buttonElement.Text.Equals("01"))
                            break;
                    }
                    catch
                    {
                        index--;
                    }

                }
                //   int a = index;
                for (int i = index; i <= tdinTbodyforDayList.Count + index; i++)
                {
                    try
                    {
                        IWebElement buttonElement1 = tdinTbodyforDayList[i].FindElement(By.TagName("button"));
                        if (buttonElement1.Text.Equals(datetoSet))
                        {
                            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", buttonElement1);
                            getWebElement(uiElement).SendKeys(Keys.Tab);
                            //   Thread.Sleep(3000);
                            driver.FindElement(By.XPath("//body")).Click();
                            break;
                        }
                    }
                    catch { }

                }
            }
            //}

            return true;
        }

        public void sleepInSecond(int sec)
        {
            System.Threading.Thread.Sleep(1000 * sec);
        }

        public String getMessageDisplayed()
        {
            sleepInSecond(5);
            String strMessage = String.Empty;
            int cnt = 0;
            do
            {
                try
                {
                    IWebElement validationMessageElement = driver.FindElement(By.Id("toast-container"));
                    IWebElement messageElement = validationMessageElement.FindElement(By.ClassName("toast-message"));
                    strMessage = messageElement.Text.ToString();
                    LogPass("Message Displayed is " + strMessage);
                }
                catch
                {
                    cnt = cnt + 1;
                    sleepInSecond(2);
                }
            } while (strMessage == String.Empty && cnt < 10);
            closeMessage();
            //  
            return strMessage;
        }

        public void closeMessage()
        {
            try
            {
                driver.FindElement(By.CssSelector(".toast-close-button")).Click();
                LogInfo("Message has been closed");
                sleepInSecond(3);
            }
            catch
            {
                LogInfo("Error while closing message");
            }

        }

        public bool clickOnKebab()
        {

            if (isIPHONE || isAndroid)
            {
                IWebElement element = null;
                try
                {
                    element = getWebElements(new UIElement(UIType.LABEL, UILocatorType.XPATH, "//*[@class='cs-folder-toolbar-row' or @class='cs-grid-toolbar']//a[contains(@class,'toggle-button')]")).First(a => a.Displayed);
                }
                catch
                {
                    element = getWebElements(new UIElement(UIType.LABEL, UILocatorType.XPATH, "//*[@cs-keypress='toggleMenu()']//a[contains(@class,'toggle-button')]")).First(a => a.Displayed);
                }
                 ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", element);
                element.Click();
                return true;
            }

            return true;
        }

    }
}

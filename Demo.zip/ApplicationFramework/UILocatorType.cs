﻿namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    public enum UILocatorType
    {
        ID,
        NAME,
        XPATH,
        CLASS_NAME,
        CSS_SELECTOR,
        LINK_TEXT,
        PARTIAL_LINK_TEXT,
        TAGNAME
    }
}

﻿namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    class UIElement
    {

        UILocatorType uiLocatorType;
        UIType uiType;
        string locator;

        public UIElement() { }

        public UIElement(UIType uiType, UILocatorType uiLocatorType, string locator) {
            this.uiLocatorType = uiLocatorType;
            this.uiType = uiType;
            this.locator = locator;
        }

        public string getLocator() {
            return this.locator;
        }

        public UIType getUIType() {
            return this.uiType;
        }

        public UILocatorType getUILocatorType()
        {
            return this.uiLocatorType;
        }

       
    }
}

﻿using System;
using System.IO;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{

    public class FileCreations
    {
        private static String ReportFolderName = "Logs" + "\\TestRun_" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-fff");
        private static String ScreenshotFolderName = ReportFolderName + "\\ErrorScreenshots";
        public static String ASSEMBLY_LOCATION = System.Reflection.Assembly.GetExecutingAssembly().Location;
        public static String PROJECT_LOCATION = ASSEMBLY_LOCATION.Substring(0, ASSEMBLY_LOCATION.IndexOf("\\bin"));
        public static String ReportFolderPath = Path.Combine(PROJECT_LOCATION, ReportFolderName);
        public static String ScreenshotPath = Path.Combine(PROJECT_LOCATION, ScreenshotFolderName);

        public static void GetReportFolderPath()
        {
            //String DateTimeStampFolder = DateTime.Now.ToString("yyyyMMddHHmmssfff");
            Directory.CreateDirectory(ReportFolderPath);
            //return ReportFolderPath;
        }

        public static void GetScreenshotFolderPath()
        {
            Directory.CreateDirectory(ScreenshotPath);
            //return ScreenshotPath;
        }
    }

}

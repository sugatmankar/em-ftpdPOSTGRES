﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using System;
using FrameworkClassLibraryDemo.CommonInitializers;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    public class CustomExtentReport
    {
        public static ExtentReports extent = null;
        public ExtentTest test;
        private static ExtentHtmlReporter htmlReporter;
        private static String filePath = FileCreations.GetReportFolderPath()+ "\\CurrentReport.html";

        // private ExtentReports report;
        private Object thisLock = new Object();

        public CustomExtentReport(ExtentTest test)
        {
            //Directory.CreateDirectory(filePath);
            this.test = test;
        }

        public static ExtentReports GetExtent()
        {
            if (extent != null)
                return extent; // avoid creating new instance of html file

            extent = new ExtentReports();
            extent.AttachReporter(getHtmlReporter());
            return extent;
        }

        public static ExtentReports GetInstance()
        {
            if (extent != null)
                return extent; // avoid creating new instance of html file

            throw new Exception("ExtentReports object is not initialized");
        }

        private static ExtentHtmlReporter getHtmlReporter()
        {
            //filePath=
            htmlReporter = new ExtentHtmlReporter(filePath);

            // make the charts visible on report open
            htmlReporter.Configuration().ChartVisibilityOnOpen = true;
            htmlReporter.Configuration().DocumentTitle = "QA Automation Report";
            htmlReporter.Configuration().ReportName = "Marsh ClearSight";

            htmlReporter.AppendExisting = false;

            return htmlReporter;
        }

        public static ExtentTest createTest(String name, String description, String category, String author)
        {
            ExtentTest test = extent.CreateTest(name, description)
            .AssignCategory(category).AssignAuthor(author);
            return test;
        }

        public static ExtentTest createTest(String name, String description)
        {
            ExtentTest test = extent.CreateTest(name, description);
            return test;
        }

        public void Log(Status status, String description)
        {
            test.Log(status, description);
        }

        public void LogPass(String description)
        {
            test.Log(Status.Pass, description);
        }

        public void LogInfo(String description)
        {
            test.Log(Status.Info, description);
        }

        public void LogFail(String description)
        {
            test.Log(Status.Fail, description);
        }
        public void LogSkip(String description)
        {
            test.Log(Status.Skip, description);
        }

        public void LogError(String description)
        {
            test.Log(Status.Error, description);
        }

        public void Pass(String details)
        {
            test.Pass(details);
        }

        public void Fail(String details)
        {
            test.Fail(details);
        }

        public void Skip(String details)
        {
            test.Skip(details);
        }

        public void Error(String details)
        {
            test.Error(details);
        }
        public void AddFailNode(String NodeName, String NodeDesc, String LoggerMessage)
        {
            test.CreateNode(NodeName, NodeDesc).Fail(LoggerMessage);
        }
        public void AddPassNode(String NodeName, String NodeDesc, String LoggerMessage)
        {
            test.CreateNode(NodeName, NodeDesc).Pass(LoggerMessage);
        }
        public void ErrorNode(Exception e)
        {
            test.CreateNode("Error : ").Error(e);
            test.Error(e);
        }

        public void StepNode(String s)
        {
            test.CreateNode("Step : ").Info(s);
        }
        public void FailNode(String NodeName, String LoggerMessage)
        {
            test.CreateNode(NodeName).Fail(LoggerMessage);
        }
        public void InfoNode(String NodeName, String LoggerMessage)
        {
            test.CreateNode(NodeName).Info(LoggerMessage);
        }
        public void PassNode(String NodeName, String LoggerMessage)
        {
            test.CreateNode(NodeName).Pass(LoggerMessage);
        }
        public void Flush()
        {

                extent.Flush();
        }

        public String AddBold(String s) { return "<span style='font-weight:bold;'>" + s + "</span>"; }
        public String AddBreak(String s) { return s + "<br />"; }
    }
}
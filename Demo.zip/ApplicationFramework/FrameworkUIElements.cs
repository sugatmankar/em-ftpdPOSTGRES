﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FrameworkClassLibraryDemo.PageObjects;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    class FrameworkUIElements : CommonPageObjectFunctions
    {
        [FindsBy(UIType = UIType.LABEL, UILocatorType = UILocatorType.CSS_SELECTOR, Using = "iframe[id^='canvas-outer-_:']")]
        public UIElement OuterFrame;

        [FindsBy(UIType = UIType.LABEL, UILocatorType = UILocatorType.CSS_SELECTOR, Using = "iframe[id^='canvas-inner-_:']")]
        public UIElement InnerFrame;
    }
}

﻿using AventStack.ExtentReports;
using NUnit.Framework;
using System;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    public class Logger
    {
        public void Log(Status status, String description)
        {
            ExtentTestManager.GetTest().Log(status, description);
        }

        public void LogPass(String description)
        {
            ExtentTestManager.GetTest().Log(Status.Pass, AddBold(description));
        }

        public void LogInfo(String description)
        {
            ExtentTestManager.GetTest().Log(Status.Info, AddBold(description));
        }

        public void LogStepInfo(String description)
        {
            ExtentTestManager.GetTest().Log(Status.Info, AddBoldSteps(description));
        }

        public void LogFail(String description)
        {
            ExtentTestManager.GetTest().Log(Status.Fail, description);
            Assert.Fail();
        }

        public void LogSkip(String description)
        {
            ExtentTestManager.GetTest().Log(Status.Skip, description);
        }

        public void LogError(String description)
        {
            ExtentTestManager.GetTest().Log(Status.Error, description);
        }

        public void Pass(String details)
        {
            ExtentTestManager.GetTest().Pass(details);
        }

        public void Fail(String details)
        {
            ExtentTestManager.GetTest().Fail(details);
        }

        public void Skip(String details)
        {
            ExtentTestManager.GetTest().Skip(details);
        }

        public void Error(String details)
        {
            ExtentTestManager.GetTest().Error(details);
        }
        public void AddFailNode(String NodeName, String NodeDesc, String LoggerMessage)
        {
            ExtentTestManager.GetTest().CreateNode(NodeName, NodeDesc).Fail(LoggerMessage);
        }
        public void AddPassNode(String NodeName, String NodeDesc, String LoggerMessage)
        {
            ExtentTestManager.GetTest().CreateNode(NodeName, NodeDesc).Pass(LoggerMessage);
        }
        public void ErrorNode(Exception e)
        {
            ExtentTestManager.GetTest().CreateNode("Error : ").Error(e);
            ExtentTestManager.GetTest().Error(e);
        }

        public void StepNode(String s)
        {
            ExtentTestManager.GetTest().CreateNode("Step : ").Info(s);
        }
        public void FailNode(String NodeName, String LoggerMessage)
        {
            ExtentTestManager.GetTest().CreateNode(NodeName).Fail(LoggerMessage);
        }
        public void InfoNode(String NodeName, String LoggerMessage)
        {
            ExtentTestManager.GetTest().CreateNode(NodeName).Info(LoggerMessage);
        }
        public void PassNode(String NodeName, String LoggerMessage)
        {
            ExtentTestManager.GetTest().CreateNode(NodeName).Pass(LoggerMessage);
        }

        public String AddBold(String s) { return "<span style='font-weight:bold;'>" + s + "</span>"; }
        public String AddBoldSteps(String s) { return "<span style='font-weight:bold; color:rgb(255, 145, 9);'>" + s + "</span>"; }
        public String AddBreak(String s) { return s + "<br />"; }
    }
}

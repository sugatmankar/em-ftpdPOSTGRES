﻿using FrameworkClassLibraryDemo.PageActions;
using FrameworkClassLibraryDemo.PageObjects;
using FrameworkClassLibraryDemo.ValueObjects;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    class ClaimFinancialCommonFunctions : ApplicationCommonFunction
    {
        private FinancialsHomePO financialsHomePO;
        private ClaimFinancialsHomeActions claimFinancialsHomeActions;
        private ClaimFinancialsNewTransactionActions claimFinancialsNewTransactionActions;
        private CreateNewTransactionVO createNewTransactionVO;

        public ClaimFinancialCommonFunctions()
        {
            financialsHomePO = new FinancialsHomePO();
            claimFinancialsHomeActions = new ClaimFinancialsHomeActions();
            createNewTransactionVO = new CreateNewTransactionVO();
            claimFinancialsNewTransactionActions = new ClaimFinancialsNewTransactionActions();
        }

        public bool navigateToFinancialsTab()
        {
            if (isIPAD || isIPHONE || isAndroid)
            {
                navigateToTabs("Financials");
            }
            else
            {
                claimFinancialsHomeActions.ClickOnClaimFinancials();
            }
            if (isDisplayed(financialsHomePO.GetUIElement(nameof(financialsHomePO.FinancialsTransactionsTableContainer))))
            {
                return true;
            }
            return true;
        }

        public bool createNewTransaction(CreateNewTransactionVO createNewTransactionVO)
        {
            if (createNewTransactionVO.isNavigateToFinancials)
            {
                navigateToFinancialsTab();
            }

            if (createNewTransactionVO.isClickOnNewTransaction && createNewTransactionVO.transactionName != null)
            {
                //System.Threading.Thread.Sleep(5000);
                waitForPleaseWaitDisappear();
                if (isEnabled(financialsHomePO.GetUIElement(nameof(financialsHomePO.NewTranscationButton))))
                {
                    claimFinancialsHomeActions.ClickOnNewTransaction();
                }
            }

            if (createNewTransactionVO.transactionName != null)
            {
                claimFinancialsNewTransactionActions.ClickOnTransactionType(createNewTransactionVO.transactionName);
            }

            if (createNewTransactionVO.transactionType != null)
            {
                //System.Threading.Thread.Sleep(8000);
                waitForPleaseWaitDisappear();
                claimFinancialsNewTransactionActions.selectTrasactionType(createNewTransactionVO.transactionType);
            }

            if (createNewTransactionVO.transactionAmount != null)
            {
                claimFinancialsNewTransactionActions.enterTransactionAmount("500");
            }

            if (createNewTransactionVO.isSave)
            {
                claimFinancialsNewTransactionActions.clickOnSaveButton();
                try
                {
                    claimFinancialsNewTransactionActions.clickOnDuplicateTransactionSaveButton();
                }
                catch
                { }
                getMessageDisplayed();
            }

            return true;
        }

    }
}

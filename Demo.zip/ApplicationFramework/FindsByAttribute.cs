﻿using System;
using System.ComponentModel;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
    public sealed class FindsByAttribute : Attribute
    {
      
        [DefaultValue(UILocatorType.ID)]
        public UILocatorType UILocatorType { get; set; }

        [DefaultValue(UIType.LABEL)]
        public UIType UIType { get; set; }
        
        public string Using { get; set; }


    }

    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
    public sealed class FindsByIPHONEAttribute : Attribute
    {

        [DefaultValue(UILocatorType.ID)]
        public UILocatorType UILocatorType { get; set; }

        [DefaultValue(UIType.LABEL)]
        public UIType UIType { get; set; }

        public string Using { get; set; }


    }
}

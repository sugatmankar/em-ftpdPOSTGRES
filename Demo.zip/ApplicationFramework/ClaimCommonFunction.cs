﻿using FrameworkClassLibraryDemo.PageActions;
using FrameworkClassLibraryDemo.PageObjects;
using FrameworkClassLibraryDemo.ValueObjects;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    class ClaimCommonFunction : ApplicationCommonFunction
    {
        private NewClaimActions newClaimActions;
        private ClaimHomeActions claimHomeActions;

        public ClaimCommonFunction()
        {    
            claimHomeActions = new ClaimHomeActions();
            newClaimActions = new NewClaimActions();
        }

        public bool CreateNewClaim(CreateNewClaimVO createNewClaimVO)
        {
            if (createNewClaimVO.IsClickOnNewClaim)
            {
                claimHomeActions.Click_Button_NewClaim();
            }

            if(createNewClaimVO.STARSclient!="")
            {
                newClaimActions.SelectClient();
            }
            else
            {
                newClaimActions.SelectClient();
            }

            if (createNewClaimVO.ClaimNumber != "")
            {
                newClaimActions.SetValueInClaim(createNewClaimVO.ClaimNumber);
            }
            else
            {
                newClaimActions.SetValueInClaim("SID09041");
            }

            if (createNewClaimVO.Coverages != "")
            {
                newClaimActions.SelectCoverage();
            }
            else
            {
                newClaimActions.SelectCoverage();
            }

            if (createNewClaimVO.IsNext)
            {
                newClaimActions.Click_Button_NextOK();
            }

            
            if (createNewClaimVO.ClaimantName != "")
            {
                newClaimActions.SetValueInClaimantName(createNewClaimVO.ClaimantName);
            }
            else
            {
                newClaimActions.SetValueInClaimantName("xyz");
            }

            if (createNewClaimVO.LossDate != "")
            {
                newClaimActions.SetValueInLossDate();
            }
            else
            {
                newClaimActions.SetValueInLossDate();
            }

            if (createNewClaimVO.ReportDate != "")
            {
                newClaimActions.SetValueInReportDate();
            }
            else
            {
                newClaimActions.SetValueInReportDate();
            }

            if (createNewClaimVO.Location != "")
            {
                newClaimActions.SelectLocation();
            }
            else
            {
                newClaimActions.SelectLocation();
            }

            if (createNewClaimVO.Currency != "")
            {
                newClaimActions.SelectCurrency();
            }
            else
            {
                newClaimActions.SelectCurrency();
            }

            if (createNewClaimVO.IsSave)
            {
                newClaimActions.Click_Button_SaveClaim();
                getMessageDisplayed();
            }

            return true;
        }       

    }
}

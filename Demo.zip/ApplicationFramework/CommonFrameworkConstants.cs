﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkClassLibraryDemo.ApplicationFramework
{
    class CommonFrameworkConstants
    {
        public static String ClaimsAdmin_StormsID = "Storms.ClaimsAdmin";
    }
}

﻿using FrameworkClassLibraryDemo.ApplicationFramework;

namespace FrameworkClassLibraryDemo.PageObjects
{
    class ClaimHomePagePO :  CommonPageObjectFunctions
    {
       // public UIElement newClaimButton = new UIElement(UIType.BUTTON, UILocatorType.XPATH, "//button[contains(text(),'New')]");
        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[contains(text(),'New')]")]
        public UIElement newClaimButton;

        //public UIElement myClaimTabButton = new UIElement(UIType.BUTTON, UILocatorType.XPATH, "//button[normalize-space(text())='My Claims']");
        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[normalize-space(text())='My Claims']")]
        public UIElement myClaimTabButton;

       // public UIElement newClaimPageLabel = new UIElement(UIType.LABEL, UILocatorType.XPATH, "//button[contains(text(),'New')]");
        [FindsBy(UIType = UIType.LABEL, UILocatorType = UILocatorType.XPATH, Using = "//button[contains(text(),'New')]")]
        public UIElement newClaimPageLabel;

        //public UIElement claimTable = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//table");
        [FindsByIPHONE(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.XPATH, Using = "//div[@class='cs-group-list-view']")]
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.XPATH, Using = "//table")]
        public UIElement claimTable;

      //  public UIElement navigateInnerFolderInClaimsLink = new UIElement(UIType.LINK, UILocatorType.CLASS_NAME, "cs-folder-nav");
        [FindsBy(UIType = UIType.LINK, UILocatorType = UILocatorType.CLASS_NAME, Using = "cs-folder-nav")]
        public UIElement navigateInnerFolderInClaimsLink;
    }
}

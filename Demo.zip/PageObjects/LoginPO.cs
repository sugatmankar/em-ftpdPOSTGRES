﻿using FrameworkClassLibraryDemo.ApplicationFramework;

namespace FrameworkClassLibraryDemo.PageObjects
{
    class LoginPO : CommonPageObjectFunctions
    {

        //public UIElement clientIDTextbox1 = new UIElement(UIType.TEXTBOX, UILocatorType.ID, "txtClientID");

        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.ID, Using = "txtClientID")]
        public UIElement clientIDTextbox1;

        //public UIElement usernameTextbox1 = new UIElement(UIType.TEXTBOX, UILocatorType.ID, "txtUserID");
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.ID, Using = "txtUserID")]
        public UIElement usernameTextbox1;

        //public UIElement passwordTextbox1 = new UIElement(UIType.TEXTBOX, UILocatorType.ID, "txtPassword");
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.ID, Using = "txtPassword")]
        public UIElement passwordTextbox1;

        //public UIElement loginButton1 = new UIElement(UIType.BUTTON, UILocatorType.XPATH, "//*[@id='cmdLogin']");
        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//*[@id='cmdLogin']")]
        public UIElement loginButton1;

        //public UIElement clientIDTextbox = new UIElement(UIType.TEXTBOX, UILocatorType.ID, "txtClientID");
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.ID, Using = "txtClientID")]
        public UIElement clientIDTextbox;

        //public UIElement usernameTextbox = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//input[contains(@id,'loginForm:username')]");
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.XPATH, Using = "//input[contains(@id,'loginForm:username')]")]
        public UIElement usernameTextbox;

        //public UIElement passwordTextbox = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//input[contains(@id,'loginForm:password')]");
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.XPATH, Using = "//input[contains(@id,'loginForm:password')]")]
        public UIElement passwordTextbox;

        //public UIElement loginButton = new UIElement(UIType.BUTTON, UILocatorType.XPATH, "//input[contains(@class,'loginFormControlButton')]");
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.XPATH, Using = "//input[contains(@class,'loginFormControlButton')]")]
        public UIElement loginButton;

        //public UIElement labelApp = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//div[contains(@class,'appNameLabelTiny')]//a[@title='ClearSight']");
        [FindsBy(UIType = UIType.LINK, UILocatorType = UILocatorType.XPATH, Using = "//div[contains(@class,'appNameLabel')]//a[@title='ClearSight']")]
        public UIElement labelApp;

        [FindsBy(UIType = UIType.LINK, UILocatorType = UILocatorType.XPATH, Using = "//*[@id='cmdLogin'")]
        public UIElement UserName;
       
    }
}

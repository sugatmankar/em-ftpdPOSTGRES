﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FrameworkClassLibraryDemo.ApplicationFramework;

namespace FrameworkClassLibraryDemo.PageObjects
{
    class FinancialsNewPagePO : CommonPageObjectFunctions
    {
        [FindsBy(UIType = UIType.LABEL, UILocatorType = UILocatorType.XPATH, Using = "//span[text()='Log Payment']")]
        public UIElement LogPaymentPageHeadingLabel;

        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.XPATH, Using = "//input[@aria-label='Amount']")]
        public UIElement TransactionAmountTextBox;

        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.CLASS_NAME, Using = "folder-save")]
        public UIElement SaveTransactionButton;

        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[contains(text(),'Save Transaction')]")]
        public UIElement SaveDuplicateTransactionButton;

        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[@title='Approve']")]
        public UIElement ClaimFinancials_Transactions_Approve_Button;

        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[@title='Reject']")]
        public UIElement ClaimFinancials_Transactions_Reject_Button;

        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[@title='Escalate']")]
        public UIElement ClaimFinancials_Transactions_Escalate_Button;

        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[@title='Delete']")]
        public UIElement ClaimFinancials_Transactions_Delete_Button;

        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[@title='Move']")]
        public UIElement ClaimFinancials_Transactions_Move_Button;

    }
}

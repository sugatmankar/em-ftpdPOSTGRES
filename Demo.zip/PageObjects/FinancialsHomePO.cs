﻿using FrameworkClassLibraryDemo.ApplicationFramework;

namespace FrameworkClassLibraryDemo.PageObjects
{
    class FinancialsHomePO : CommonPageObjectFunctions
    {
        //public UIElement FinancialsLink = new UIElement(UIType.LINK, UILocatorType.XPATH, "//ul[@title]//span[@role='menuitemradio' and text()='Financials']");
        [FindsBy(UIType = UIType.LINK, UILocatorType = UILocatorType.XPATH, Using = "//ul[@title]//span[@role='menuitemradio' and text()='Financials']")]
        public UIElement FinancialsLink;

        //public UIElement FinancialsTransactionsTableContainer = new UIElement(UIType.BUTTON, UILocatorType.XPATH, "//div[@class='financials-transactions-grid-container']");
        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//div[@class='financials-transactions-grid-container']")]
        public UIElement FinancialsTransactionsTableContainer;

        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[contains(text(),'New')]")]
        public UIElement NewTranscationButton;

        [FindsBy(UIType = UIType.LINK, UILocatorType = UILocatorType.XPATH, Using = "//a//span[contains(text(),'Log Payment')]")]
        public UIElement LogPaymentLink;       
        
    }
}

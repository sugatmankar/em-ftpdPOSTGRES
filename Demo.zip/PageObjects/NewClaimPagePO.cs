﻿using FrameworkClassLibraryDemo.ApplicationFramework;

namespace FrameworkClassLibraryDemo.PageObjects
{
    class NewClaimPagePO : CommonPageObjectFunctions
    {
        //public UIElement textbox_claimNumber = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//input[contains(@name,'ClaimNumber')]");
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.XPATH, Using = "//input[contains(@name,'ClaimNumber')]")]
        public UIElement textbox_claimNumber;

        //public UIElement button_NextOK = new UIElement(UIType.BUTTON, UILocatorType.XPATH, "//button[text()='OK']");
        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[text()='OK']")]
        public UIElement button_NextOK;

        //public UIElement textbox_claimName = new UIElement(UIType.TEXTBOX, UILocatorType.NAME, "ClaimName1");
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.NAME, Using = "ClaimName1")]
        public UIElement textbox_claimName;

        //public UIElement textbox_lossDate = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//input[@name='LossDate']");
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.XPATH, Using = "//input[@name='LossDate']")]
        public UIElement textbox_lossDate;

        //public UIElement textbox_reportDate = new UIElement(UIType.TEXTBOX, UILocatorType.XPATH, "//input[@name='ReportDate']");
        [FindsBy(UIType = UIType.TEXTBOX, UILocatorType = UILocatorType.XPATH, Using = "//input[@name='ReportDate']")]
        public UIElement textbox_reportDate;

        //public UIElement button_saveClaim = new UIElement(UIType.BUTTON, UILocatorType.XPATH, "//button[contains(@class,'folder-save')]");
        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[contains(@class,'folder-save')]")]
        public UIElement button_saveClaim;

        //public UIElement button_saveAndCloseClaim = new UIElement(UIType.BUTTON, UILocatorType.XPATH, "//button[contains(@class,'save-close')]");
        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[contains(@class,'save-close')]")]
        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//button[contains(@class,'save-close')]")]

        public UIElement button_saveAndCloseClaim;
    }
}

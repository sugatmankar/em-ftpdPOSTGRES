﻿using FrameworkClassLibraryDemo.ApplicationFramework;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace FrameworkClassLibraryDemo.PageObjects
{
    class CommonPageObjectFunctions
    {

        public UIElement GetUIElement(string property)
        {
            UIElement uIElement = null; ;
            var type = this.GetType();
            List<MemberInfo> members = new List<MemberInfo>();
            const BindingFlags PublicBindingOptions = BindingFlags.Instance | BindingFlags.Public;
            const BindingFlags NonPublicBindingOptions = BindingFlags.Instance | BindingFlags.NonPublic;
            members.AddRange(type.GetFields(PublicBindingOptions));
            members.AddRange(type.GetProperties(PublicBindingOptions));
            while (type != null)
            {
                members.AddRange(type.GetFields(NonPublicBindingOptions));
                members.AddRange(type.GetProperties(NonPublicBindingOptions));
                type = type.BaseType;
            }

            foreach (MemberInfo member in members)
            {
                if (member.Name.Equals(property))
                {

                    FindsByAttribute da = (FindsByAttribute)member.GetCustomAttribute(typeof(FindsByAttribute));
                    FindsByIPHONEAttribute dai = (FindsByIPHONEAttribute)member.GetCustomAttribute(typeof(FindsByIPHONEAttribute));
                    if (da != null)
                    {
                        uIElement = new UIElement(da.UIType, da.UILocatorType, da.Using);
                    }
                    if (ApplicationCommonFunction.isIPHONE && dai != null)
                    {
                        uIElement = new UIElement(dai.UIType, dai.UILocatorType, dai.Using);
                    }

                    /*
                    object[] attributes = member.GetCustomAttributes(true);
                    if (attributes.Length != 0)
                    {
                        foreach (object attribute in attributes)
                        {
                            FindsByAttribute da = attribute as FindsByAttribute;
                           
                            if (da != null)
                            {
                                uIElement = new UIElement(da.UIType, da.UILocatorType, da.Using);
                            }
                            else
                                Console.WriteLine();
                        }
                    }
                    else
                        Console.WriteLine("  {0} has no attributes", member.Name);

                    */
                }
            }
            return uIElement;
        }
    }
}

﻿using FrameworkClassLibraryDemo.ApplicationFramework;

namespace FrameworkClassLibraryDemo.PageObjects
{
    class DashboardsPO : CommonPageObjectFunctions
    {

        // public UIElement buttonDashBoardExpandCollapse = new UIElement(UIType.BUTTON, UILocatorType.XPATH, "//div[contains(@class,'app-title')]/span");
        [FindsBy(UIType = UIType.BUTTON, UILocatorType = UILocatorType.XPATH, Using = "//div[contains(@class,'app-title')]/span")]        
        public UIElement buttonDashBoardExpandCollapse;

    }
}

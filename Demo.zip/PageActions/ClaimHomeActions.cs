﻿using FrameworkClassLibraryDemo.ApplicationFramework;
using FrameworkClassLibraryDemo.PageObjects;
using System;

namespace FrameworkClassLibraryDemo.PageActions
{
    class ClaimHomeActions : ApplicationCommonFunction
    {
        private ClaimHomePagePO claimHomePagePO;
        private NewClaimPagePO newClaimPagePO;
        public ClaimHomeActions()
        {
            this.claimHomePagePO = new ClaimHomePagePO();
            this.newClaimPagePO = new NewClaimPagePO();
        }

        public bool Click_Button_NewClaim()
        {
            Ngclick(claimHomePagePO.GetUIElement(nameof(claimHomePagePO.myClaimTabButton)));

            Ngclick(claimHomePagePO.GetUIElement(nameof(claimHomePagePO.newClaimButton)));

            //System.Threading.Thread.Sleep(3000);
            waitForPleaseWaitDisappear();
            if (isDisplayed(newClaimPagePO.GetUIElement(nameof(newClaimPagePO.textbox_claimNumber))))
            {
                return true;
            }
            return true;
        }
    }
}

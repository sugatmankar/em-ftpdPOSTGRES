﻿using FrameworkClassLibraryDemo.ApplicationFramework;
using FrameworkClassLibraryDemo.PageObjects;
using System;

namespace FrameworkClassLibraryDemo.PageActions
{
    class ClaimFinancialsNewTransactionActions : ApplicationCommonFunction
    {
        private FinancialsHomePO financialsHomePO;
        private FinancialsNewPagePO financialsNewPagePO;
        public ClaimFinancialsNewTransactionActions()
        {
            financialsHomePO = new FinancialsHomePO();
            financialsNewPagePO = new FinancialsNewPagePO();
        }

        public bool ClickOnTransactionType(string TransactionName)
        {
            if (TransactionName.Equals("Log Payment"))
            {

                Ngclick(financialsHomePO.GetUIElement(nameof(financialsHomePO.LogPaymentLink)));
                if (isDisplayed(financialsNewPagePO.GetUIElement(nameof(financialsNewPagePO.LogPaymentPageHeadingLabel))))
                {
                    return true;
                }
            }
            return true;
        }

        public bool selectTrasactionType(string TransactionType)
        {
            if (TransactionType.Equals("BALANCE-MEDICAL"))
            {
                SelectValueFromDropdown("csLookup_TransactionTypeCode_STARS.PayRecord_RMIS", "BALANCE-MEDICAL");
                return true;
            }
            return true;
        }

        public bool enterTransactionAmount(String amount)
        {
            sendKey(financialsNewPagePO.GetUIElement(nameof(financialsNewPagePO.TransactionAmountTextBox)), amount);
            return true;
        }

        public bool clickOnSaveButton()
        {
            Ngclick(financialsNewPagePO.GetUIElement(nameof(financialsNewPagePO.SaveTransactionButton)));
            return true;
        }

        public bool clickOnDuplicateTransactionSaveButton()
        {
            Ngclick(financialsNewPagePO.GetUIElement(nameof(financialsNewPagePO.SaveDuplicateTransactionButton)));
            return true;
        }
    }
}

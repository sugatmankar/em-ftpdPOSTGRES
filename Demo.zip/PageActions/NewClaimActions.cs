﻿using FrameworkClassLibraryDemo.ApplicationFramework;
using FrameworkClassLibraryDemo.PageObjects;
using System;

namespace FrameworkClassLibraryDemo.PageActions
{
    class NewClaimActions : ApplicationCommonFunction
    {

        private ClaimHomePagePO claimHomePagePO;
        private NewClaimPagePO newClaimPagePO;
        public NewClaimActions()
        {
            this.claimHomePagePO = new ClaimHomePagePO();
            this.newClaimPagePO = new NewClaimPagePO();
        }

        public bool SelectClient()
        {
            SelectValueFromDropdown("csLookup_SetID_STARS.Claim_RMIS", "1Client_For_Automation");
            return true;
        }

        public bool SelectCoverage()
        {
            SelectValueFromDropdown("csLookup_CoverageCode_STARS.Claim_RMIS", "Coverage_For_Automation");
            return true;
        }

        public bool SetValueInClaim(String claimNumber)
        {
            sendKey(newClaimPagePO.GetUIElement(nameof(newClaimPagePO.textbox_claimNumber)), claimNumber);
            return true;
        }

        public bool SetValueInClaimantName(String claimantName)
        {
            sendKey(newClaimPagePO.GetUIElement(nameof(newClaimPagePO.textbox_claimName)), claimantName);
            return true;
        }

        public bool SetValueInLossDate()
        {
            //sendKey(newClaimPagePO.GetUIElement(nameof(newClaimPagePO.textbox_lossDate)), "4/6/2018");
            setDateinOnDemand(newClaimPagePO.GetUIElement(nameof(newClaimPagePO.textbox_lossDate)), DateTime.Now);
            return true;
        }

        public bool SetValueInReportDate()
        {
            //sendKey(newClaimPagePO.GetUIElement(nameof(newClaimPagePO.textbox_reportDate)), "4/6/2018");
            setDateinOnDemand(newClaimPagePO.GetUIElement(nameof(newClaimPagePO.textbox_reportDate)), DateTime.Now);
            return true;
        }

        public bool Click_Button_NextOK()
        {
            Ngclick(newClaimPagePO.GetUIElement(nameof(newClaimPagePO.button_NextOK)));
            return true;
        }

        public bool SelectLocation()
        {
            SelectValueFromDropdown("csLookup_LocationID_STARS.Claim_RMIS", "Automation_Location_ClearSight");
            return true;
        }

        public bool SelectCurrency()
        {
            SelectValueFromDropdown("csLookup_CurrencyCode_STARS.Claim_RMIS", "US Dollar");
            return true;
        }

        public bool Click_Button_SaveClaim()
        {
            Ngclick(newClaimPagePO.GetUIElement(nameof(newClaimPagePO.button_saveClaim)));
            return true;
        }

        public bool Click_Button_SaveAndCloseClaim()
        {
            Ngclick(newClaimPagePO.GetUIElement(nameof(newClaimPagePO.button_saveAndCloseClaim)));
            return true;
        }

    }
}

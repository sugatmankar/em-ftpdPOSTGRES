﻿using FrameworkClassLibraryDemo.ApplicationFramework;
using FrameworkClassLibraryDemo.PageObjects;

namespace FrameworkClassLibraryDemo.PageActions
{
    class ClaimFinancialsHomeActions : ApplicationCommonFunction
    {
        
        private FinancialsHomePO financialsHomePO;
        public ClaimFinancialsHomeActions()
        {
            financialsHomePO = new FinancialsHomePO();
        }

        public bool ClickOnClaimFinancials()
        {
            Ngclick(financialsHomePO.GetUIElement(nameof(financialsHomePO.FinancialsLink)));
            return true;
        }

        public bool ClickOnNewTransaction()
        {
            Ngclick(financialsHomePO.GetUIElement(nameof(financialsHomePO.NewTranscationButton)));
            return true;
        }

    }
}

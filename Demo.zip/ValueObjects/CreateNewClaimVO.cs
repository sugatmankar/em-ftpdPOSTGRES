﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkClassLibraryDemo.ValueObjects
{
    class CreateNewClaimVO
    {
        //private string STARSclient = "";
        //private string ClaimNumber = "";
        //private string Coverages = "";
        //private string ClaimantName = "";
        //private string LossDate = "";
        //private string ReportDate = "";
        //private string Location = "";
        //private string Currency = "";
        //private string messageToVerify = "";

        //private bool isNext = true;
        //private bool isCancel = false;
        //private bool isSave = true;
        //private bool isClickOnNewClaim = true;
        //private bool isSaveAndClose = false;

        public string STARSclient { get; set; }
        public string Coverages { get; set; }
        public string ClaimNumber { get; set; }
        public string ClaimantName { get; set; }
        public string LossDate { get; set; }
        public string ReportDate { get; set; }
        public string Location { get; set; }
        public string Currency { get; set; }
        public string MessageToVerify { get; set; }

        public bool IsNext { get; set; }
        public bool IsCancel { get; set; }
        public bool IsSave { get; set; }
        public bool IsClickOnNewClaim { get; set; }
        public bool IsSaveAndClose { get; set; }


        // Get STARS Client
        //public string GetSTARSClient()
        //{
        //    return STARSclient;
        //}
        ////Set STARS Client
        //public void SetSTARSClient(string STARSclient)
        //{
        //    this.STARSclient = STARSclient;
        //}
        // Get Claim Number
        //public string getClaimNumber()
        //{
        //    return ClaimNumber;
        //}
        ////Set Claim Number
        //public void SetClaimNumber(string ClaimNumber)
        //{
        //    this.ClaimNumber = ClaimNumber;
        //}
        //// Get Coverages
        //public string GetCoverages()
        //{
        //    return Coverages;
        //}
        ////Set Coverages
        //public void SetCoverages(string Coverages)
        //{
        //    this.Coverages = Coverages;
        //}
        //// set Next Button Click Yes

        //public bool GetisClickNextYES()
        //{
        //    return isNext;
        //}
        //public void SetisClickNextYES(bool isNext)
        //{
        //    this.isNext = isNext;
        //}

        //// set Next Button Click Cancel
        //public bool GetisClickNextCancel()
        //{
        //    return isCancel;
        //}
        //public void SetisClickNextCancel(bool isCancel)
        //{
        //    this.isCancel = isCancel;
        //}

        //// Get Claimant Name
        //public string GetClaimantName()
        //{
        //    return ClaimantName;
        //}
        ////Set Claimant Name
        //public void SetClaimantName(string ClaimantName)
        //{
        //    this.ClaimantName = ClaimantName;
        //}
        //// Get Loss Date
        //public string GetLossDate()
        //{
        //    return LossDate;
        //}
        ////Set Loss Date
        //public void SetLossDate(string LossDate)
        //{
        //    this.LossDate = LossDate;
        //}
        //// Get Report Date
        //public string getReportDate()
        //{
        //    return ReportDate;
        //}
        ////Set Report Date
        //public void SetReportDate(string ReportDate)
        //{
        //    this.ReportDate = ReportDate;
        //}
        //// Get Location
        //public string GetLocation()
        //{
        //    return Location;
        //}
        ////Set Location
        //public void SetLocation(string Location)
        //{
        //    this.Location = Location;
        //}
        //// Get Currency
        //public string GetCurrency()
        //{
        //    return Currency;
        //}
        ////Set Currency
        //public void SetCurrency(string Currency)
        //{
        //    this.Currency = Currency;
        //}

        ////Set Save-> Yes
        //public bool GetisSave()
        //{
        //    return isSave;
        //}
        //public void SetisSave(bool isSave)
        //{
        //    this.isSave = isSave;
        //}
        ////Set Save And Close
        //public bool GetisSaveAndClose()
        //{
        //    return isSaveAndClose;
        //}
        //public void SetisSaveAndClose(bool isSaveAndClose)
        //{
        //    this.isSaveAndClose = isSaveAndClose;
        //}
        ////verifying message Save Success       
        //public string GetMessageToVerify()
        //{
        //    return messageToVerify;
        //}
        //public void SetMessageToVerify(string messageToVerify)
        //{
        //    this.messageToVerify = messageToVerify;
        //}
        ////Set New Claim Click
        //public bool GetisClickOnNewClaim()
        //{
        //    return isClickOnNewClaim;
        //}
        //public void SetisClickOnNewClaim(bool isClickOnNewClaim)
        //{
        //    this.isClickOnNewClaim = isClickOnNewClaim;
        //}

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkClassLibraryDemo.ValueObjects
{
    class CreateNewTransactionVO
    {
        public string transactionName { get; set; }
        public string transactionAmount { get; set; }
        public string transactionType { get; set; }

        public bool isNavigateToFinancials { get; set; }
        public bool isClickOnNewTransaction { get; set; }
        public bool isSave { get; set; }
    }
}

﻿using FrameworkClassLibraryDemo.ApplicationFramework;
using FrameworkClassLibraryDemo.PageObjects;
using FrameworkClassLibraryDemo.ValueObjects;
using System;

namespace FrameworkClassLibraryDemo.WorkFlow
{
    class CreateAndSearchClaim : ApplicationCommonFunction
    {

        private Login login;
        private ClaimCommonFunction claimCommonFunction;
        private CreateNewClaimVO createNewClaimVO;
        private CreateNewTransactionVO createNewTransactionVO;
        private ClaimFinancialCommonFunctions claimFinancialCommonFunctions;
        private FinancialsNewPagePO financialsNewPagePO;
        String sClaimNumber = "SID" + DateTime.Now.ToString("MMddHHmmssfff");

        public CreateAndSearchClaim()
        {
            claimCommonFunction = new ClaimCommonFunction();
            login = new Login();
            createNewClaimVO = new CreateNewClaimVO();
            createNewTransactionVO = new CreateNewTransactionVO();
            claimFinancialCommonFunctions = new ClaimFinancialCommonFunctions();
            financialsNewPagePO = new FinancialsNewPagePO();
        }

        public bool testCreateAndSearchClaim()
        {
            LogInfo("@Pre-requisite : Pre-Requisite:1. Provide all access/permissions for Claim &amp; Claim Transaction entity into logged-In user security group.2. Create a reserve &amp; payment transaction on existing claim");

            login.testLogin();

            //--------------------------------------------------------------------------------
            // Step 1: 1. Login to Claim Admin app &amp; open an existing Claim.2. Go to Financials  Transaction Tab &amp; open an existing payment transaction.3. Verify whether user is able to view Approve, Escalate, Reject, Delete &amp; Move buttons on Claim Transaction folder page.
            // Expected Result: The Approve, Escalate, Reject, Delete &amp; Move buttons should be available on Claim Transaction folder page when user open an existing Claim transaction.
            //--------------------------------------------------------------------------------

            LogInfo("Step 4: 1. Login to Claim Admin app &amp; open an existing Claim.2. Go to Financials  Transaction Tab &amp; open an existing payment transaction.3. Verify whether user is able to view Approve, Escalate, Reject, Delete &amp; Move buttons on Claim Transaction folder page.");
            LogInfo("Expected Result: The Approve, Escalate, Reject, Delete &amp; Move buttons should be available on Claim Transaction folder page when user open an existing Claim transaction.");

            //create claim
            createNewClaimVO.IsClickOnNewClaim = true;
            createNewClaimVO.ClaimNumber = sClaimNumber;
            createNewClaimVO.ClaimantName = "xyz";
            createNewClaimVO.IsNext = true;
            createNewClaimVO.IsSave = true;
            if (claimCommonFunction.CreateNewClaim(createNewClaimVO))
            {
                LogPass("Successfully able to create Claim");
            }
            else
            {
                LogFail("Unable to create Claim");
                return false;
            }

            createNewTransactionVO.isNavigateToFinancials = true;
            createNewTransactionVO.isClickOnNewTransaction = true;
            createNewTransactionVO.transactionName = "Log Payment";
            createNewTransactionVO.transactionType = "BALANCE-MEDICAL";
            createNewTransactionVO.transactionAmount = "500";
            createNewTransactionVO.isSave = true;
            if (claimFinancialCommonFunctions.createNewTransaction(createNewTransactionVO))
            {
                LogPass("Successfully able to create Transaction");
            }
            else
            {
                LogFail("Unable to create Transaction");
                return false;
            }

            clickOnKebab();

            if (isDisplayed(financialsNewPagePO.GetUIElement(nameof(financialsNewPagePO.ClaimFinancials_Transactions_Approve_Button))))
            {
                LogPass(AddBold("Successfully verified that Approve, Reject, Esaclete, Delete and Move button are displayed in Transaction page."));
            }
            else
            {
                LogFail(AddBold("Failed to verify that Approve, Reject, Esaclete, Delete and Move button are displayed in Transaction page."));
            }

            return true;
        }
    }
}

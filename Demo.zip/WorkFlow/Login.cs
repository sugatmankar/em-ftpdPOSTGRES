﻿using FrameworkClassLibraryDemo.ApplicationFramework;
using FrameworkClassLibraryDemo.PageObjects;
using System;

namespace FrameworkClassLibraryDemo.WorkFlow
{
    class Login : ApplicationCommonFunction
    {

        //private ApplicationCommonFunction applicationCommonFunction;
        private LoginPO loginPO;
        private DashboardsPO dashboardPO;
        private ClaimHomePagePO claimHomePagePO;


        public Login()
        {
            this.loginPO = new LoginPO();
            this.dashboardPO = new DashboardsPO();
            this.claimHomePagePO = new ClaimHomePagePO();
        }

        public bool testLogin()
        {
            LogStepInfo("Step1: Navigate to application");
            navigateToApplication();
            LogStepInfo("Step2: Enter Username And Password and click on login button");

            if (isIPAD || isIPHONE)
            {
                sendKey(loginPO.GetUIElement(nameof(loginPO.clientIDTextbox1)), "E321TEST_TR_AUTO");
                sendKey(loginPO.GetUIElement(nameof(loginPO.usernameTextbox1)), "automation1");
                enterPassword(loginPO.GetUIElement(nameof(loginPO.passwordTextbox1)), "Stars5me");
                Ngclick(loginPO.GetUIElement(nameof(loginPO.loginButton1)));
                System.Threading.Thread.Sleep(5000);
                navigateToApp("Claims Administration");
            }
            else
            {
                sendKey(loginPO.GetUIElement(nameof(loginPO.usernameTextbox)), "automation1@stars-net.com");
                enterPassword(loginPO.GetUIElement(nameof(loginPO.passwordTextbox)), "Welcome!5");
                click(loginPO.GetUIElement(nameof(loginPO.loginButton)));
                if (isDisplayed(loginPO.GetUIElement(nameof(loginPO.labelApp))))
                {
                    LogPass("Successfully Logged in to the application");
                }
                else
                {
                    LogFail("Failed to login to the application");
                    return false;
                }

                LogStepInfo("Step3: Open Application E321Test_TR_AUTO");
                Ngclick(loginPO.GetUIElement(nameof(loginPO.labelApp)));
                SwitchtoHeaderFrameNew();
                Ngclick(dashboardPO.GetUIElement(nameof(dashboardPO.buttonDashBoardExpandCollapse)));
                navigateToApp("Claims Administration");
                SwitchtoHeaderFrameNew();
                SwitchToAppFrame();
            }
            if (isDisplayed(claimHomePagePO.GetUIElement(nameof(claimHomePagePO.claimTable))))
            {
                LogPass("Successfully Navigated to Claims Admin App");
            }
            else
            {
                LogFail("Unable to navigate to Claims Admin App");
                return false;
            }

            return true;
        }

    }
}

﻿using FrameworkClassLibraryDemo.ApplicationFramework;
using FrameworkClassLibraryDemo.WorkFlow;
using NUnit.Framework;

namespace FrameworkClassLibraryDemo.RuntimeTestSuite
{
    class TestBase : BaseFixture
    {       

        [Test]
        [Repeat(1)]
        public void testLogin()
        {
            Login login = new Login();
            login.testLogin();
        }

        [Test]
        [Repeat(1)]
        public void testCreateAndSearchClaim()
        {
            CreateAndSearchClaim createAndSearchClaim = new CreateAndSearchClaim();
            createAndSearchClaim.testCreateAndSearchClaim();
        }
    }
}

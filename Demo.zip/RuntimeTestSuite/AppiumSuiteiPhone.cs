﻿using FrameworkClassLibraryDemo.ApplicationFramework;
using FrameworkClassLibraryDemo.WorkFlow;
using NUnit.Framework;

namespace FrameworkClassLibraryDemo.RuntimeTestSuite
{
    class AppiumSuiteiPhone : BaseFixture
    {       

        [Test]
        [Repeat(1)]
        public void TestMethod1()
        {
            Login login = new Login();
            login.executeTest();
        }

        [Test]
        [Repeat(1)]
        public void TestMethod2()
        {
            CreateAndSearchClaim createAndSearchClaim = new CreateAndSearchClaim();
            createAndSearchClaim.executeTest();
        }
    }
}
